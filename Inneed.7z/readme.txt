cd --> raiz de proyecto ..\Inneed

mvn clean
mvn package 
java -jar target\Inneed-0.1.0.jar
